DotNetOpenMail README

INTRODUCTION
------------------------------------------------

DotNetOpenMail is a Microsoft .Net library which can be 
used to create html and text emails with file attachments
and embedded images.  You need an SMTP server and
your own .Net program to make use of it.

See http://dotnetopenmail.sourceforge.net/ for the
latest downloads and discussion groups.


QUICK START
------------------------------------------------

1) Copy the DotNetOpenMail.dll and log4net dlls into
   a directory where your project can access it
2) Create a Reference to it from within your project
3) Try some examples from the web site:
	
		http://dotnetopenmail.sourceforge.net/examples.html

