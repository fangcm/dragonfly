namespace FluentScheduler
{
    internal enum TimeOfDayRunnable
    {
        TooEarly,
        CanRun,
        TooLate,
    }
}