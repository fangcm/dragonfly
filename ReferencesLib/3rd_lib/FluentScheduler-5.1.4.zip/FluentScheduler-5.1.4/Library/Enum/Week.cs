﻿namespace FluentScheduler
{
    internal enum Week
    {
        First,
        Second,
        Third,
        Fourth,
        Last,
    }
}
